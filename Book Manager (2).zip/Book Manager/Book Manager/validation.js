const joi = require('joi');

const schema = joi.object({
    id:joi.number().integer().min(1).max(50).messages({
        'number.base': 'id must be a number',
        'number.integer': 'id must be an integer',
        'number.min': 'id must be greater than 1',
        'number.max': 'id must be less than or equal to 1',
        
    }),
    Title:joi.string().min(1).max(50).required().messages({
        'string.base': 'Title must be a string',
        'string.min': 'Title must be at least 1 character long',
        'string.max': 'Title must be at most 50 characters long',
        'any.required':"Book Title is required"
        }),
    Author:joi.string().min(3).max(20).required().messages({
        'string.base': 'author must be a string',
        'string.min': 'author must be at least 3 characters long',
        'string.max': 'author must be at most 20 characters long',
        'any.required':"Author name is required"
        }),
    Publisher:joi.string().min(2).max(15).required().messages({
        'string.base': 'publisher must be a string',
        'string.min': 'publisher must be at least 2 characters long',
        'string.max': 'publisher must be at most 15 characters long',
        'any.required':"Publisher name is required"
        }),
});

    const BookIdSchema = joi.object({
        
        id:joi.number().integer().min(1).max(50).required().messages({
        'number.base': 'id must be a number',
        'number.integer': 'id must be an integer',
        'number.min': 'id must be greater than 1',
        'number.max': 'id must be less than or equal to 50',
        'any.required': "Book id is required"
        }),
});

const updateSchema = joi.object({
    id:joi.number().integer().min(1).max(50).required().messages({
        'number.base': 'id must be a number',
        'number.integer': 'id must be an integer',
        'number.min': 'id must be greater than 1',
        'number.max': 'id must be less than or equal to 50',
        'any.required':"Book id is required",
    }),
    Title:joi.string().min(1).max(50).messages({
        'string.base': 'Title must be a string',
        'string.min': 'Title must be at least 1 character long',
        'string.max': 'Title must be at most 50 characters long',
        'any.required':"Book Title is required",
        }),
    Author:joi.string().min(3).max(20).required().messages({
        'string.base': 'author must be a string',
        'string.min': 'author must be at least 3 characters long',
        'string.max': 'author must be at most 20 characters long',
        'any.required':"Book name is required",
        
        }),
    Pulisher:joi.string().min(2).max(15).required().messages({
        'string.base': 'publisher must be a string',
        'string.min': 'publisher must be at least 2 characters long',
        'string.max': 'publisher must be at most 15 characters long',
        'any.required':"Book name is required",
        }),
});


const validatebook =(req,res,next)=>{
const {error} = schema.validate(req.body,{abortEarly:false});
if(error){
    const errorMessage = error.details.map((ele)=>ele.message)
    res.status(400).json({error: errorMessage});
    return;
    }
 next();
};


const validatebookId = (req,res,next)=>{
    const {error} = BookIdSchema.validate(req.params.id,{abortEarly:false });
    if(error){
        const errorMessage = error.details.map((ele)=>ele.message)
        res.status(400).json({error: errorMessage});
}
next();
};

const validateupdate = (req,res,next)=>{
    const {error} = updateSchema.validate(req.body,{abortEarly:false});
    if(error){
        const errorMessage = error.details.map((ele)=>ele.message)
        res.status(400).json({error: errorMessage});
        }
        next();
};


module.exports ={validatebook,validatebookId,validateupdate}        