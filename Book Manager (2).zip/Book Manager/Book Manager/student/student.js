const Students = require("./student.model")
const Books = require("../books.model")

//const selectstudent = async()=>{
    //     const student = await Students.findAll({include:Books});
    //     return students;
    //     };
    
    //     const selectstudentbyBook = async(BookName)=>{
    //       const Bookstudents = await Students.findOne({where:{name: BookName},
    //       include: {model:Students, as: "Student"}});
    //       return BookStudents;
    //       };
    
    
    //     const getStudentbook = async(studentId)=>{
    //       const studentbook= await Students.findOne({
    //       where:{id:studentId},
    //       include:{model:Books}});
    //       if (!studentbook) {
    //         return null;
    //       }
    //       return studentbook
    //     };
    
       
    
    //     const createStudent = async (studentDetail) => {
    //       studentDetail.User.password = bcrypt.hashSync(
    //         studentDetail.User.password,
    //         10
    //       );
    //       const student = await Student.create(studentDetail, {
    //         include: [{ model: User, as: "User" }],
    //       });
    //       return student;
    //     };
    
    // const updateStudent = async (studentId, BookId,studentDetail) => {
    //     const { book, ...student } = studentDetail;
    //     const studentValue = await Students.findOne({ where: { id: studentId } });
    //     if (!studentValue) {
    //       return null;
    //     }
    //     if (book) {
    //       await Books.update(book, { where: { id: studentValue.BookId } });
    //     }
    //     const res = await Students.update(student, { where: { id: studentValue.id } });
    //     return res;
    //   };
    
    //     module.exports ={
    //         selectstudent,
    //         createStudent,
    //         updateStudent,
    //         getStudentClub,
    //         selectstudentbycourse
    //     }