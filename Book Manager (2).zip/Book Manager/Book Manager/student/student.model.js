const sequelize = require("../sequelize/config");
const { DataTypes } = require("sequelize");
const Books = require("../books.model")

const Students = sequelize.define('Student',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    email:{
        type: DataTypes.STRING,
        allowNull: false,
        },

},{timestamps:true, createdAt:true,updatedAt:true,tableName:'student'});

Books.hasMany(Students);
Students.belongsTo(Books);


module.exports = Students;