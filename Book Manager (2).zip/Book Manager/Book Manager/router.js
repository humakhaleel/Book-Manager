const express = require('express');

const {E} = require('sequelize');
const { addBooks,getAllBook,getbookById, updatebooks,deleteBooks } = require('./books');
const {validatebook,validatebookId,validateupdate} = require("./validation");

const router = express.Router();

router.get("/allbooks",async (req,res)=>{
    const bookData = await getAllBook();
res.status(200).json({
    booksdata: bookData,

   });
});

router.get("/selectbook/:bookid",validatebookId,async(req,res)=>{
const bookdata = await getbookById(Number(req.params.bookid))
if (bookdata) {
res.status(200).json({
bookdata,
});
}else {
res.status(404).json({
error : "books data not found"})
};});

router.post("/create",validatebook,async(req,res)=>{
    const bookData = await addBooks(req.body)
    console.log(bookData);
    res.status(201).json({
        booksdata: bookData,})
});

router.put("/books/:bookid",validateupdate,async(req,res)=>{
    const newbook = await updatebooks(Number(req.params.bookid), req.body);
    if (!newbook){
        res.status(404).json({
        message: "book not found"});}
else {
    res.status(200).json({
        updatedata : newbook,
    });
   }
});

router.delete("/Books/Bookid",async(req,res)=>{
    const deletebook = await  deleteBooks(Number(req.params.bookid));
    if (!deletebook){
        res.status(404).json({
            message: "book not found"});
            }
            else {
                res.status(200).json({
                   delBook: deletebook,
});
}
});

module.exports=router;
