const Books = require("./books.model");
const Students = require("../student/student.model")

const getAllBook = ()=>{
    const allBooks = Books.findAll({include: Students});
    return allBooks;
};

const getbookById = async(bookid)=>{
    const book = await Books.findOne({where :{id: bookid}});
    return book;
}

const addBooks = async (books)=>{
    const createBooks = await Books.create(books);
    return createBooks;
};

const updatebooks = async (bookid,bookdata)=>{
   const newbook = await Books.findOne({where:{id:bookid}});
   if (!newbook) {
    return null;
   }
   const update = await Books.update(bookdata({where:{id:bookid}}));
   return update;
};

const deleteBooks = async (bookid)=>{
    const delBook = await Books.findOne({where:{id:bookid}})
    if (!delBook) {
        return null;
    }
    const deletebook = await Books.destroy({where:{id:bookid}});
    return deletebook;
};
            



module.exports = {
getAllBook,
addBooks,
getbookById,
updatebooks,
deleteBooks,
}