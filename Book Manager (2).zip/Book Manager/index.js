const express = require('express');
const bodyParser = require('body-parser');
const sequelize = require('./sequelize/config');
const Books = require('./Book Manager/books.model');
const Students = require("./student/student.model")
const app = express();
const bookroute = require("./Book Manager/router");
const studentroute = require("./student/route");


sequelize.authenticate().then(async()=>{
    await sequelize.sync({alter:true});
    await Books.sync({alter:true});
    await Students.sync({alter:true});
    console.log('Database connected and synced');
}).catch((error)=>{
    console.log("Error in database", error);
});

app.use (bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());

app.use("/book",bookroute);
app.use("/student",studentroute);

app.listen(3012,()=>{
    console.log('Server is running on port 3012');
});