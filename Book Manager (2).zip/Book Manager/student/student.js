const Students = require("./student.model")
const Books = require("../Book Manager/books.model")

const getAllstudent = async()=>{
const student = await Students.findAll({include:Books});
return student;
};
    
    
const getStudentbook = async(studentId)=>{
const studentbook= await Students.findOne({
where:{id:studentId},
include:{model:Books}});
if (!studentbook) {
return null;
}
return studentbook
};
    
       
    
const createStudent = async(studentDetail)=>{
const student = await Students.create(studentDetail,
{include:[{model: Books, as: "Books"}],});
return student;
}
    
const updateStudent = async (studentId, BookId,studentDetail) => {
const { book, ...student } = studentDetail;
const studentValue = await Students.findOne({ where: { id: studentId } });
if (!studentValue) {
return null;
}
if (book) {
await Books.update(book, { where: { id: studentValue.BookId } });
}
const res = await Students.update(student, { where: { id: studentValue.id } });
return res;
};
    
module.exports ={
getAllstudent,
createStudent,
updateStudent,
getStudentbook,
}