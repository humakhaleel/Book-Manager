const express = require('express');
const {createStudent,getAllstudent, updateStudent, getStudentbook}=require("./student")

const {E} = require('sequelize');
const router = express.Router();

router.get("/allstudent",async (req,res)=>{
    const studentdata = await getAllstudent();
res.status(200).json({
    studentdata: studentdata,

   });
});

router.get("/selectstudent/:studentid",async(req,res)=>{
const studentdata = await getStudentbook
(Number(req.params.studentid))
if (studentdata) {
res.status(200).json({
studentdata,
});
}else {
res.status(404).json({
error : "student data not found"})
};});


router.post("/createStudent",async(req,res)=>{
const newstudentdata = await createStudent(req.body);
res.status(201).json({
StudentData : newstudentdata,
});
});

router.put("/update/:studentid",async(req,res)=>{
const newstudent = await updateStudent(Number(req.params.studentid), req.body);
if (!newstudent){
res.status(404).json({
message: "book not found"});}
else {
res.status(200).json({
updatedata : newstudent,
});
}
});



module.exports = router