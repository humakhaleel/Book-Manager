const {Sequelize} = require('sequelize');

const sequelize = new Sequelize({
    dialect: 'postgres',
    host: 'localhost',
    username: 'postgres',
    password: 'Publication',
    database: 'My_Books_Data',
    port: 5432,
});

module.exports = sequelize;